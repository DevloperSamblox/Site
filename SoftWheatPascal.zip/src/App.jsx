import React from 'react';
import './App.css';
const hStyle = { color: 'green' };


function App() {
  return (
   <div style={{ 
      backgroundImage: `url("https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Black_flag.svg/750px-Black_flag.svg.png")` 
    }}> 
    <main style={ hStyle}>
      Este site foi feito com tecnologias recentes, criado por DevMachine
    </main>
    </div>
  );
}

export default App;